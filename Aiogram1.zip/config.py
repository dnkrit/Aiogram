from dotenv import load_dotenv
import os

load_dotenv()

TOKEN = os.getenv("TOKEN")
WEATHER_API_KEY = os.getenv("WEATHER_API_KEY")
